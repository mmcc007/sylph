from uiautomator import Device, JsonRPCError
from subprocess import call
from timeout_decorator import timeout, TimeoutError
from sys import argv
from time import sleep, time
import os
import re
import argparse


class OneTimePopupHandler:

    region = "us-west-2"
    profile = "default"
    verbose = False
    provisioning = False
    output_dir = None

    # d is the uiautomator Device corresponding to this handler
    d = None


    # Create a parser to accept command line arguments.
    def parse_arguments(self):
        parser = argparse.ArgumentParser()
        parser.add_argument("--region", type=str, help="AWS Region")
        parser.add_argument("--profile", type=str, help="AWS Profile")
        parser.add_argument("--output-dir", dest="output_dir", type=str, 
            help="output directory for screenshots and screendumps")
        parser.add_argument("-p", "--provisioning", action="store_true", dest="provisioning",
            help="perform truly one-time popup steps if you're provisioning a device")
        parser.add_argument("-v", "--verbose", action="store_true", dest="verbose",
            help="print debug messages to stdout and write extra screendumps and screenshots")
        args = parser.parse_args(argv[1:])
        for arg in vars(args):
            setattr(self, arg, getattr(args, arg))

    # Initialize the UIAutomator device
    def initialize_device(self, retry=True):
        try:
            self.d = Device()
            self.d.orientation = "n"
        except JsonRPCError as e:
            if retry:
                self.initialize_device(retry=False)
            else:
                raise e

    # Create a uiautomator Device when we create a OneTimePopupHandler object
    def __init__(self):
        self.initialize_device()
        if self.verbose:
            self.dump_screen_information("starting_screen")

    # Delete the uiautomator Device when we create a OneTimePopupHandler object,
    # and uninstall any added packages from the device
    def __del__(self):
        if self.verbose:
            self.dump_screen_information("ending_screen")
        self.d = None
        for command in [["adb", "uninstall", "com.github.uiautomator"],
            ["adb", "uninstall", "com.github.uiautomator.test"],
            ["adb", "shell", "am", "start", "-a", "android.intent.action.MAIN",
                "-c", "android.intent.category.HOME"]]:
            try:
                call(command)
            except Exception:
                pass

    def dump_screen_information(self, name, dump=None):
        """
        Method to capture a screenshot and dump the screen hierarchy of elements, saving these things
        to the previously-specified output_dir


        Args:
            name (str): The name of the screenshot at name.png and the screendump at name_screendump.txt
            dump (str): A optional previous screendump already captured and saved (as an optimization)
        """
        if self.output_dir:
            if not os.path.isdir(self.output_dir):
                call(["mkdir", "-p", self.output_dir])
            if not dump:
                dump = self.d.dump()
            with open(os.path.join(self.output_dir, name+"_screendump.txt"), "w") as f:
                f.write(dump.encode("ascii", "ignore"))
            call(["adb", "shell", "screencap", "-p", "/sdcard/%s.png"%name])
            call(["adb", "pull", "/sdcard/%s.png"%name])
            call(["mv", name+".png", self.output_dir])
            call(["adb", "shell", "rm", "/sdcard/%s.png"%name])

    def trigger_and_handle_app_switch_popup(self):
        """
        Triggers and handles the popup explaining how the app switcher works
        """
        self.d.press(0xbb)
        sleep(3)
        if self.verbose:
            print("Handling app switcher initial prompts")
            self.dump_screen_information("handling_app_switcher_prompts")
        if self.d(textMatches=".*(?i)\\b(ok).*").exists:
            self.d(textMatches=".*(?i)\\b(ok).*").click.wait()
        if self.verbose:
            print("Handled app switcher initial prompts")
            self.dump_screen_information("handled_app_switcher_prompts")
        self.d.press.back()
        self.d.press.back()

    def trigger_and_handle_one_time_popups(self):
        """
        Triggers and handles all truly one-time popups
        """
        self.trigger_and_handle_app_switch_popup()

    def handle_initial_popups(self):
        """
        Triggers and handles the "initial" popups explaining how full-screen apps and multiwindow work
        """
        screen_dump = self.d.dump()
        if self.verbose:
            print("Handling general app initial prompts")
            self.dump_screen_information("handling_app_initial_prompts", dump=screen_dump)
        i = 0
        while i < 3 and not ((screen_dump.find('resourceId="com.android.chrome:id/menu_button"') != -1) or
            (screen_dump.find('resourceId="com.android.chrome:id/tab_switcher_button"') != -1) or
            (screen_dump.find('text="Search or type web address"') != -1) or
            (screen_dump.find('className="android.widget.CheckBox"') != -1)):
            sleep(1)
            i+=1
            screen_dump = self.d.dump()
        if ((screen_dump.find('className="android.widget.CheckBox"') != -1) and not
            self.d(className="android.widget.CheckBox").checked):
            self.d(className="android.widget.CheckBox").click.wait()
        if re.search('text=".*(?i)\\b(ok).*"', screen_dump) and self.d(textMatches=".*(?i)\\b(ok).*").exists:
            self.d(textMatches=".*(?i)\\b(ok).*").click.wait()
        if self.verbose:
            print("Handled general app initial prompts")
            self.dump_screen_information("handled_app_initial_prompts")

    def handle_initial_chrome_prompts(self):
        """
        Handles the popups explaining the google chrome ToS
        """
        screen_dump = self.d.dump()
        if self.verbose:
            print("Handling Chrome initial prompts")
            self.dump_screen_information("starting_chrome_initial_prompts", dump=screen_dump)
        if ((screen_dump.find('className="android.widget.CheckBox"') != -1) and
            self.d(className="android.widget.CheckBox").checked):
            self.d(className="android.widget.CheckBox").click()
        if re.search('text=".*(?i)\\b(accept).*"', screen_dump) and self.d(textMatches=".*(?i)\\b(accept).*").exists:
            self.d(textMatches=".*(?i)\\b(accept).*").click.wait()
            sleep(1)
            screen_dump = self.d.dump()
        if re.search('text=".*(?i)\\b(continue).*"', screen_dump) and self.d(textMatches=".*(?i)\\b(continue).*").exists:
            self.d(textMatches=".*(?i)\\b(continue).*").click.wait()
            sleep(1)
            screen_dump = self.d.dump()
        if re.search('text=".*(?i)\\b(no).*"', screen_dump) and self.d(textMatches=".*(?i)\\b(no).*").exists:
            self.d(textMatches=".*(?i)\\b(no).*").click.wait()
        if self.verbose:
            print("Handled Chrome initial prompts")
            self.dump_screen_information("finishing_chrome_initial_prompts", dump=screen_dump)

    def find_text_box(self):
        """
        Find and return a text box for the text box popup handler
        """
        if self.verbose:
            print("Finding a text box")
            self.dump_screen_information("finding_text_box")
        text_box = self.d(className="android.widget.EditText")
        if not text_box.exists:
            if self.verbose:
                print("Restarting Chrome and scrolling up to try and find one")
            call(["adb", "shell", "am", "start", "-n",
                "com.android.chrome/com.google.android.apps.chrome.Main"])
            i=0
            while i < 3 and not text_box.exists:
                self.d().swipe.up()
                i+=1
                text_box = self.d(className="android.widget.EditText")
        if self.verbose:
            print("Finished finding a text box")
            self.dump_screen_information("finished_finding_text_box")
        return text_box

    def check_for_keyboard_tips(self):
        """
        Handles the popups explaining how the keyboard works via some helpful "tips"
        """
        if self.d(className="android.widget.CheckBox", textContains="Do not").exists:
            if self.verbose:
                print("Handling keyboard tips popup dialog")
                self.dump_screen_information("handling_keyboard_tips")
            if (self.d(className="android.widget.CheckBox", textContains="Do not").exists and not
                self.d(className="android.widget.CheckBox", textContains="Do not").checked):
                self.d(className="android.widget.CheckBox", textContains="Do not").click.wait()
            if self.d(className="android.widget.Button", textContains="Next").exists:
                self.d(className="android.widget.Button", textContains="Next").click.wait()
            if (self.d(className="android.widget.CheckBox", textContains="Do not").exists and not
                self.d(className="android.widget.CheckBox", textContains="Do not").checked):
                self.d(className="android.widget.CheckBox", textContains="Do not").click.wait()
            if self.d(className="android.widget.Button", textContains="Dismiss").exists:
                self.d(className="android.widget.Button", textContains="Dismiss").click.wait()
            if self.verbose:
                print("Handled keyboard tips popup dialog")
                self.dump_screen_information("handled_keyboard_tips")

    def handle_keyboard_settings(self):
        """
        Goes to the keyboard settings and disables any predictive text analytics stuff
        """
        if self.d(text="Settings").exists:
            self.d(text="Settings").click.wait()
            screen_dump = self.d.dump()
            if self.verbose:
                print("Disabling keyboard predictive settings")
                self.dump_screen_information("handling_predictive_settings", dump=screen_dump)
            i = 0
            while i < 10 and not (re.search('text=".*(?i)\\b(Personalized).*"', screen_dump) or
                re.search('text=".*(?i)\\b(personal language).*"', screen_dump) or
                re.search('text=".*(?i)\\b(Predictive).*"', screen_dump)):
                sleep(1)
                i+=1
                screen_dump = self.d.dump()
            if (re.search('text=".*(?i)\\b(Personalized).*"', screen_dump) and 
                self.d(textContains="Personalized",).exists and
                self.d(textContains="Personalized",).right(className="android.widget.CheckBox") and
                self.d(textContains="Personalized",).right(className="android.widget.CheckBox").checked):
                self.d(textContains="Personalized",).right(className="android.widget.CheckBox").click.wait()
            if (re.search('text=".*(?i)\\b(personal language).*"', screen_dump) and 
                self.d(textContains="personal language",).exists and 
                self.d(textContains="personal language",).right(className="android.widget.CheckBox") and
                self.d(textContains="personal language",).right(className="android.widget.CheckBox").checked):
                self.d(textContains="personal language",).right(className="android.widget.CheckBox").click.wait()
            if (re.search('text=".*(?i)\\b(Personalized).*"', screen_dump) and
                self.d(textContains="Personalized",className="android.widget.CheckBox").exists and
                self.d(textContains="Personalized",className="android.widget.CheckBox").checked):
                self.d(textContains="Personalized",className="android.widget.CheckBox").click.wait()
            if (re.search('text=".*(?i)\\b(Predictive).*"', screen_dump) and
                self.d(textContains="Predictive", resourceId="android:id/action_bar_title").exists and 
                self.d(textContains="Predictive", resourceId="android:id/action_bar_title").right(
                    className="android.widget.Switch") and
                self.d(textContains="Predictive", resourceId="android:id/action_bar_title").right(
                    className="android.widget.Switch").checked):
                self.d(textContains="Predictive", resourceId="android:id/action_bar_title").right(
                    className="android.widget.Switch").click.wait()
            if self.verbose:
                print("Disabled keyboard predictive settings")
                self.dump_screen_information("handled_predictive_settings", dump=screen_dump)
            if (re.search('text=".*(?i)\\b(Personalized).*"', screen_dump) or
                re.search('text=".*(?i)\\b(personal language).*"', screen_dump) or
                re.search('text=".*(?i)\\b(Predictive).*"', screen_dump)):
                self.d.press.back()
                sleep(2)

    def handle_text_popups(self, retry=True):
        """
        Handles any popups prompted by text boxes
        """
        try:
            if retry and self.verbose:
                print("Handling text box popups")
                self.dump_screen_information("handling_text_box_popups",)
            if self.d(className="android.widget.CheckBox").exists and self.d(className="android.widget.CheckBox").checked:
                self.d(className="android.widget.CheckBox").click.wait()
            self.check_for_keyboard_tips()
            self.handle_keyboard_settings()
            self.check_for_keyboard_tips()
            if self.d(text="No").exists:
                self.d(text="No").click.wait()
            if self.d(text="OK").exists:
                self.d(text="OK").click.wait()
                sleep(2)
                if self.d(className="android.widget.EditText").exists:
                    self.d(className="android.widget.EditText").click.wait()
            if (self.d(className="android.widget.CheckBox", textContains="Do not").exists and not
                self.d(className="android.widget.CheckBox", textContains="Do not").checked):
                self.d(className="android.widget.CheckBox", textContains="Do not").click.wait()
                if self.d(text="OK").exists:
                    self.d(text="OK").click.wait()
            if (self.d(className="android.widget.CheckBox", textContains="Turn on personalized").exists and
                self.d(className="android.widget.CheckBox", textContains="Turn on personalized").checked):
                self.d(className="android.widget.CheckBox", textContains="Turn on personalized").click.wait()
            elif (self.d(className="android.widget.CheckBox", textContains="personalized").exists and not
                self.d(className="android.widget.CheckBox", textContains="personalized").checked):
                self.d(className="android.widget.CheckBox", textContains="personalized").click.wait()
            if self.d(text="OK").exists:
                self.d(text="OK").click.wait()
            if self.d(text="A picture is worth 1000 words").exists:
                self.d(text="NEXT").click.wait()
                sleep(3)
            if self.d(text="START").exists:
                self.d(text="START").click.wait()
            self.handle_keyboard_settings()
            if retry and self.verbose:
                print("Handled text box popups")
                self.dump_screen_information("handling_text_box_popups",)
        except Exception as e:
            print(type(e), e, e.message if "message" in e.__dict__ else "")
            if retry:
                self.d = None
                self.d = Device()
                if self.verbose:
                    print("Handling text box popups attempt 2")
                    self.dump_screen_information("handling_text_box_popups_retry",)
                self.handle_text_popups(retry=False)

    def check_if_text_popups_dismissed(self):
        """
        Checks if we can enter text in a text box
        """
        if self.verbose:
            print("Trying to enter text in a textbox")
            self.dump_screen_information("attempting_to_enter_text")
        text_box = self.d(className="android.widget.EditText")
        text_box.click()
        text_box.clear_text()
        text_box.set_text("Hello!")
        screen_dump = self.d.dump()
        i = 0
        while i < 3 and not (screen_dump.find('text="Hello!"') != -1):
            sleep(1)
            i+=1
            screen_dump = self.d.dump()
        if not (screen_dump.find('text="Hello!"') != -1):
            if self.verbose:
                print("Failed to enter text because the popup prevented us")
            self.dump_screen_information("failed_to_dismiss_text_popup", dump=screen_dump)
            return False
        text_box.clear_text()
        if self.verbose:
            print("Entered the text just fine")
            self.dump_screen_information("successfully_dismiss_text_popup", dump=screen_dump)
        return True

    @timeout(10 * 60)
    def perform_popup_walkthrough(self):
        '''
        Perform a walkthrough of the steps to initiate and dismiss many one-time popups. This includes the
        following popups (in general order of appearence):
            - The app drawer explaination (if provisioning_device is True)
            - The multi window tray explaination
            - Pop-up view explaination
            - Keyboard layout popup
            - Samsung keyboard tips
            - Samsung keyboard predictive results
            - LG keyboard predictive data
            - Samsung "a picture is worth 1000 words" GIF keyboard explaination
        '''
        success = False
        try:
            if self.provisioning:
                self.trigger_and_handle_one_time_popups()

            call(["adb", "shell", "am", "start", "-n",
                "com.android.chrome/com.google.android.apps.chrome.Main"])

            self.handle_initial_popups()
            self.handle_initial_chrome_prompts()

            text_box = self.find_text_box()

            if not text_box.exists:
                print("Failed because we couldn't find a text box to click!")
                self.dump_screen_information("failed_to_find_textbox")
            else:
                text_box.click.wait()
                sleep(1)
                self.handle_text_popups()

                success = self.check_if_text_popups_dismissed()

        except Exception as e:
            if type(e) is TimeoutError:
                raise e
            try:
                print("Failed due to an error:", type(e), e, e.message if "message" in e.__dict__ else "")
                self.dump_screen_information("failed_due_to_python_error_"+str(e).strip('()'))
            except Exception:
                print("Ran into another error while handling the first error")

        return success


if __name__ == "__main__":
    start_time = time()
    print("Starting one-time popup handler! Walking through some "
        +"standard UI interactions, and dismissing popups along the way")
    popup_handler_class = OneTimePopupHandler()
    popup_handler_class.parse_arguments()
    try:
        success = popup_handler_class.perform_popup_walkthrough()
    except TimeoutError:
        print("Timed out while trying to walk through popups")
        success = False
        popup_handler_class.dump_screen_information("timed_out_at_this_point")
    popup_handler_class = None
    print("Took %s to complete the popup dismissal walkthrough"%(time()-start_time))
    if not success:
        exit(1)
